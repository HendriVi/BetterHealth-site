# BetterHealth GitHub Pages
This folder is ready for GitHub Pages.

## What to do
1) Upload everything in this folder to a GitHub repository.
2) In GitHub: Settings → Pages → Deploy from a branch → main / (root)
3) Your site will appear at: https://<your-username>.github.io/<repo-name>/

## Notes
- This is a static site (single index.html).
